package com.mycompany.hola

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
