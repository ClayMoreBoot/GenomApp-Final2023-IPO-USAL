// Export pages
export '/pages/inciar_sesion_registrarse/inciar_sesion_registrarse_widget.dart'
    show InciarSesionRegistrarseWidget;
export '/pages/perfil/perfil_widget.dart' show PerfilWidget;
export '/pages/desplegado/desplegado_widget.dart' show DesplegadoWidget;
export '/pages/animal/animal_widget.dart' show AnimalWidget;
export '/pages/inicio/inicio_widget.dart' show InicioWidget;
export '/pages/escaner/escaner_widget.dart' show EscanerWidget;
export '/pages/buscador/buscador_widget.dart' show BuscadorWidget;
export '/pages/lista_animales/lista_animales_widget.dart'
    show ListaAnimalesWidget;
export '/pages/editar_perfil/editar_perfil_widget.dart' show EditarPerfilWidget;
export '/pages/recordar_contrasena/recordar_contrasena_widget.dart'
    show RecordarContrasenaWidget;
export '/pages/personalizacion/personalizacion_widget.dart'
    show PersonalizacionWidget;
export '/pages/despliegue/despliegue_widget.dart' show DespliegueWidget;
